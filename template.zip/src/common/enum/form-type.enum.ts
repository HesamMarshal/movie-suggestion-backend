export enum FormType {
  Json = "application/json",
  Urlencoded = "application/x-www-form-urlencoded",
  Multipart = "multipart/form-data",
}
