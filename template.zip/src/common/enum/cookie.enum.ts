export enum CookieKeys {
  OTP = "otp",
}
